import { createContext } from "react";
export const CustomProps = createContext()