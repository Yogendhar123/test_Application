import React, { useContext } from 'react'
import { Button } from '@mui/material'
import { CustomProps } from './CustomProps'



const Header = () => {
    const { setdialog, setsignupOPen, setloginopen, setforgotpasword,
        dataUser
    } = useContext(CustomProps)

    const LoginFunction = () => {
        setdialog(true)
        setsignupOPen(false)
        setloginopen(true)
        setforgotpasword(false)

    }

    const SignupFUnction = () => {
        setdialog(true)
        setsignupOPen(true)
        setloginopen(false)
        setforgotpasword(false)

    }
    return (
        <div style={{ padding: "10px 60px", backgroundColor: "skyblue", alignItems: "center" }} className='d-flex justify-content-between' >
            <div >
                <div className='Humber'>  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-list" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5m0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5m0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5" />
                </svg></div>
                <div style={{ fontWeight: "bold" }}>School Web App</div>



            </div>
            <div style={{ display: "flex", gap: "6px", alignItems: "center", justifyContent: "end" }}>
                <div><Button size='small' variant='contained' sx={{ textTransform: "none" }} onClick={LoginFunction}>Login</Button></div>
                <div><Button size='small' variant='contained' sx={{ textTransform: "none", backgroundColor: "red" }} onClick={SignupFUnction}> Sign UP</Button></div>
                <div style={{ display: "flex", justifyContent: "center", alignItems: "center", borderRadius: "50%", height: "30px", width: "30px", background: "white", marginLeft: "10px" }}>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person" viewBox="0 0 16 16">
                        <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6m2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0m4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4m-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10s-3.516.68-4.168 1.332c-.678.678-.83 1.418-.832 1.664z" />
                    </svg>
                </div>
                {dataUser && (<>  <div className='boxHOver'>
                    <div style={{}}>
                        <div>
                            <label>User :</label>
                            <div>{ }</div>


                        </div>
                        <div>
                            <label>Role :</label>
                            <div>{ }</div>

                        </div>
                        <div>
                            <label>Logout</label>
                            <div>

                            </div>

                        </div>
                    </div>

                </div></>)}

            </div>


        </div>
    )
}

export default Header