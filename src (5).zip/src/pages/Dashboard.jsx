import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'


import Landing from './Landing'
import Admin from './Admin'
import User from './User'


const Dashboard = () => {
    return (
        <div style={{ height: "100%" }}>
            <BrowserRouter>
                <Routes>
                    <Route path='/' element={<Landing />} />
                    <Route path='/admin' element={<Admin />} />
                    <Route path='/user' element={<User />} />

                </Routes>

            </BrowserRouter>

        </div>
    )
}

export default Dashboard