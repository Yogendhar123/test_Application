import React from 'react'
import "../stylings/landing.css"
const Landing = () => {
    return (
        <div className='LandingMinBOx'>
            <div className='landBanner'>
                <div className='TextMOTStyle'>
                    Success is the sum of small efforts, repeated day in and day out.

                </div>

            </div>
            <div className='contnetContainer'>
                <div className='Datacontnet'>
                    <div className='commonContainers'>

                    </div>
                    <div className='commonContainers'>

                    </div>
                    <div className='commonContainers'>

                    </div>

                </div>

            </div>




        </div>
    )
}

export default Landing