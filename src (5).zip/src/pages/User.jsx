import React from 'react'

const User = () => {
    return (
        <div>

            user
        </div>
    )
}

export default User