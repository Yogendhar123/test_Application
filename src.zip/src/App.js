import React from "react";
import Signup from "./components/Signup";

const App = () => {
  return (
    <div style={{ height: "100%" }}>
      <Signup />
    </div>
  );
};

export default App;
