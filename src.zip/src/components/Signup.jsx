import React, { useState } from 'react'
import "../stylings/signup.css"
import { Button } from '@mui/material'

const Signup = () => {
    const [formData, setformDate] = useState({
        user: "",
        mail: "",
        password: "",
        confirmpassword: "",

    })


    const InputChange = (e) => {
        setformDate({ ...formData, [e.target.name]: e.target.value })

    }
    const SubmitData = async (e) => {
        e.preventDefault();
        if (formData.password !== formData.confirmpassword) {
            alert("Password do not match!")
        }
        // const data = {
        //     name: formData.user,
        //     mail: formData.mail,
        //     password: formData.password
        // }
        // console.log(data)

        // try {
        //     const reponse = await fetch("http://localhost:5000/api/auth/signup", {
        //         method: "POST",
        //         headers: {
        //             "Content-Type": "application/json"
        //         },
        //         body: JSON.stringify(data)

        //     })
        //     const apires = await reponse.json()
        //     console.log(apires)



        // } catch (error) {
        //     console.log("Internal server error")
        //     alert(error)

        // }

    }
    return (
        <div className='Section h-100 w-100 d-flex justify-content-center align-items-center'>
            <form onSubmit={SubmitData}>
                <div >
                    <label>User Name</label>
                    <input type='text' name='user' value={formData?.user} onChange={InputChange} required />

                </div>
                <div>
                    <label>Email</label>
                    <input type='email' name='mail' value={formData?.mail} onChange={InputChange} required />
                </div>
                <div>
                    <label>Password</label>
                    <input type='text' name='password' value={formData?.password} onChange={InputChange} required />
                </div>
                <div>
                    <label>Confirm Password</label>
                    <input type='text' name='confirmpassword' value={formData?.confirmpassword} onChange={InputChange} required />
                </div>
                <div>
                    <Button type='submit' size='small' variant='contained' sx={{ background: "red", borderRadius: "" }}>Sign UP</Button>
                </div>

            </form>


        </div>
    )
}

export default Signup